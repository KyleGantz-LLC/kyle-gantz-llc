
export default function Home(){return <main style={{maxWidth:900,margin:'auto',padding:40}}>
<h1>Kyle Gantz LLC</h1>
<h2>Turning Ideas Into Powerful Software</h2>
<p>Custom websites, software development, freelance programming, UI/UX, and business automation.</p>
<h3>Services</h3><ul><li>Website Development</li><li>Custom Software</li><li>Freelance Development</li></ul>
<h3>Why Choose Me?</h3><p>I help businesses and entrepreneurs build modern, reliable digital solutions.</p>
<p><b>GitHub:</b> https://github.com/KyleGantz-LLC</p>
<p><b>Email:</b> pickrik420@gmail.com</p>
<footer style={{marginTop:40}}>© 2026 Kyle Gantz LLC</footer>
</main>}
